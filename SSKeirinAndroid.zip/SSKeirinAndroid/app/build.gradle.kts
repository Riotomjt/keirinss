plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
}

android {
  namespace = "com.sskeirin.app"
  // GMA Next-Gen SDK の必須要件: compileSdk 35以上
  compileSdk = 35

  defaultConfig {
    applicationId = "com.sskeirin.app"
    // GMA Next-Gen SDK の必須要件: minSdk 24以上
    minSdk = 24
    targetSdk = 35
    versionCode = 1
    versionName = "1.0"
  }

  buildTypes {
    release {
      isMinifyEnabled = false
      proguardFiles(
        getDefaultProguardFile("proguard-android-optimize.txt"),
        "proguard-rules.pro"
      )
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_1_8
    targetCompatibility = JavaVersion.VERSION_1_8
  }

  kotlinOptions {
    // GMA Next-Gen SDK の必須要件: Kotlin 1.9以上
    jvmTarget = "1.8"
  }

  buildFeatures {
    viewBinding = true
  }
}

dependencies {
  implementation("androidx.core:core-ktx:1.13.1")
  implementation("androidx.appcompat:appcompat:1.7.0")
  implementation("com.google.android.material:material:1.12.0")
  implementation("androidx.constraintlayout:constraintlayout:2.1.4")

  // SDK初期化をバックグラウンドスレッドで行うために必要
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

  // ── ユーザーが組み込みたいと指定した依存関係 ──────────────────
  implementation("com.google.android.libraries.ads.mobile.sdk:ads-mobile-sdk:1.1.1")
}
