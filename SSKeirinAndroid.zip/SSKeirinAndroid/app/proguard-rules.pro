# このファイルに ProGuard / R8 用のルールを追加できます。
# 詳細: http://developer.android.com/guide/developing/tools/proguard.html
