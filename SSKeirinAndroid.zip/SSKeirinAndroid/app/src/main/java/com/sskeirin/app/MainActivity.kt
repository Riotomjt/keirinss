package com.sskeirin.app

import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize
import com.google.android.libraries.ads.mobile.sdk.banner.AdView
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdEventCallback
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest
import com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAd
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdEventCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "SSKeirin"

        // SSケイリンの公開URL
        private const val GAME_URL = "https://keirinss.netlify.app"

        // AdMobアプリID（広告ユニットIDとは別物。チルダ ~ 区切り）
        private const val ADMOB_APP_ID = "ca-app-pub-5021031352922084~6120925485"

        // レース中バナー広告ユニットID
        private const val BANNER_AD_UNIT_ID = "ca-app-pub-5021031352922084/9079432179"

        // レース後インタースティシャル広告ユニットID
        private const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-5021031352922084/8915780643"
    }

    private lateinit var webView: WebView
    private lateinit var adContainer: FrameLayout
    private var adView: AdView? = null
    private var interstitialAd: InterstitialAd? = null
    private var hasShownInterstitial = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        adContainer = findViewById(R.id.adContainer)

        setupWebView()
        setupBackNavigation()
        initializeAds()
    }

    private fun setupWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                // 初回のページ読み込み完了時に一度だけインタースティシャルを表示
                if (!hasShownInterstitial) {
                    hasShownInterstitial = true
                    showInterstitialIfReady()
                }
            }
        }

        webView.loadUrl(GAME_URL)
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun initializeAds() {
        // GMA Next-Gen SDK はバックグラウンドスレッドで初期化する必要がある
        // (メインスレッドで呼ぶとANR(応答なし)の原因になる)
        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(
                this@MainActivity,
                InitializationConfig.Builder(ADMOB_APP_ID).build()
            ) {
                // アダプターの初期化完了
                Log.d(TAG, "GMA Next-Gen SDK initialized.")
                runOnUiThread {
                    loadBannerAd()
                    loadInterstitialAd()
                }
            }
        }
    }

    private fun loadBannerAd() {
        val newAdView = AdView(this)
        adContainer.addView(newAdView)
        adView = newAdView

        // 360dp幅の大型アンカー型アダプティブバナーをリクエスト
        val adSize = AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, 360)
        val adRequest = BannerAdRequest.Builder(BANNER_AD_UNIT_ID, adSize).build()

        newAdView.loadAd(
            adRequest,
            object : AdLoadCallback<BannerAd> {
                override fun onAdLoaded(ad: BannerAd) {
                    Log.d(TAG, "Banner ad loaded.")
                    ad.adEventCallback = object : BannerAdEventCallback {
                        override fun onAdClicked() {
                            Log.d(TAG, "Banner ad clicked.")
                        }
                        override fun onAdImpression() {
                            Log.d(TAG, "Banner ad recorded an impression.")
                        }
                    }
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.w(TAG, "Banner ad failed to load: $adError")
                }
            }
        )
    }

    private fun loadInterstitialAd() {
        InterstitialAd.load(
            AdRequest.Builder(INTERSTITIAL_AD_UNIT_ID).build(),
            object : AdLoadCallback<InterstitialAd> {
                override fun onAdLoaded(ad: InterstitialAd) {
                    Log.d(TAG, "Interstitial ad loaded.")
                    interstitialAd = ad
                    // 表示前にイベントコールバックを設定しておく
                    ad.adEventCallback = object : InterstitialAdEventCallback {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            // 次回表示に備えて再ロード
                            loadInterstitialAd()
                        }
                        override fun onAdFailedToShowFullScreenContent(
                            fullScreenContentError: FullScreenContentError
                        ) {
                            Log.w(TAG, "Interstitial failed to show: $fullScreenContentError")
                            interstitialAd = null
                        }
                    }
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.w(TAG, "Interstitial ad failed to load: $adError")
                    interstitialAd = null
                }
            }
        )
    }

    private fun showInterstitialIfReady() {
        interstitialAd?.show(this) ?: Log.d(TAG, "Interstitial not ready yet, skipping.")
    }

    override fun onDestroy() {
        // バナー広告のリソースを解放
        adView?.let { view ->
            (view.parent as? ViewGroup)?.removeView(view)
            view.destroy()
        }
        adView = null
        super.onDestroy()
    }
}
