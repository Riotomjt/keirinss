# SSケイリン Android アプリ

「SSケイリン」（https://keirinss.netlify.app）をWebViewで表示し、
GMA Next-Gen SDK（`com.google.android.libraries.ads.mobile.sdk:ads-mobile-sdk:1.1.1`）で
バナー広告とインタースティシャル広告を配信するAndroidラッパーアプリです。

## 開く前に必ず確認すること

### ✅ AdMobアプリID設定済み

`app/src/main/AndroidManifest.xml` と `MainActivity.kt` の両方に、
実際のAdMobアプリID `ca-app-pub-5021031352922084~6120925485` を設定済みです。

（参考: 広告ユニットID `ca-app-pub-.../数字`、スラッシュ区切り とは別物で、
AdMobアプリIDは末尾が「チルダ(~)+数字」になります。）

広告ユニットIDの確認は不要ですが、AdMobコンソール側でアプリの審査状況
（「準備が必要」「公開準備中」など）を確認しておくと、初回は広告が
表示されないことがある点に注意してください（審査完了まで数日かかる場合があります）。

### 組み込み済みの広告ユニットID

| 用途 | ID |
|---|---|
| バナー広告（画面下部） | `ca-app-pub-5021031352922084/9079432179` |
| インタースティシャル広告（初回起動時に1回表示） | `ca-app-pub-5021031352922084/8915780643` |

これらはWebサイト側のAdSenseで使っているものと同じ番号体系で
以前のやり取りでいただいたIDをそのまま使用しています。

## 開発中はテスト広告IDの利用を推奨

本番IDのまま実機テストを繰り返すと、無効なクリックとしてAdMobアカウントが
停止されるリスクがあります。開発・デバッグ中は下記のGoogle公式テストIDに
一時的に差し替えることを推奨します（`MainActivity.kt` の定数を書き換えるだけ）。

- バナー: `ca-app-pub-3940256099942544/9214589741`
- インタースティシャル: `ca-app-pub-3940256099942544/1033173712`

## プロジェクトの開き方

1. Android Studioで `SSKeirinAndroid` フォルダを開く（File → Open）
2. Gradle Sync が走るのでそのまま待つ（gradlew がない場合はAndroid Studioが自動生成）
3. 実機またはエミュレータで実行（▶ボタン）

## 構成

```
SSKeirinAndroid/
├── settings.gradle.kts          ← 指定いただいた内容をそのまま使用
├── build.gradle.kts              ← AGP / Kotlin プラグインのバージョン宣言
├── gradle.properties
└── app/
    ├── build.gradle.kts           ← ads-mobile-sdk 依存を追加済み
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml    ← INTERNET権限 + AdMobアプリID(要差し替え)
        ├── java/com/sskeirin/app/MainActivity.kt
        └── res/
            ├── layout/activity_main.xml   ← WebView + バナー広告コンテナ
            ├── drawable/ic_launcher.xml
            └── values/{strings,colors,themes}.xml
```

## 実装のポイント

- `MobileAds.initialize()` はバックグラウンドスレッド（`Dispatchers.IO`）で呼び出し、
  ANR（応答なし）を回避しています。
- バナー広告は `AdSize.getLargeAnchoredAdaptiveBannerAdSize()` を使った
  アンカー型アダプティブバナー（画面幅に応じて自動調整）です。
- インタースティシャル広告は初回ページ読み込み完了時に1回だけ表示し、
  閉じられたら次回表示に向けて自動的に再ロードします。
- 戻るボタンはまずWebView内の履歴を遡り、履歴がなければアプリを終了します。
- `onDestroy()` でバナー広告のリソースを解放しています。

## さらに発展させるなら

ゲーム内の「レース終了後3回に1回」というタイミングでネイティブの
インタースティシャルも表示したい場合は、`WebView.addJavascriptInterface()` で
JavaScriptブリッジを追加し、Web側のレース終了処理から
`Android.onRaceFinished()` のようなメソッドを呼び出す形で連携できます。
必要であれば実装します。
